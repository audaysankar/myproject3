public class HelloService {

	/**
	* This method will be the add operation of the web service.
	*/
	public int add(int x, int y) {
		int ans = x + y;
		return ans;
	}

}