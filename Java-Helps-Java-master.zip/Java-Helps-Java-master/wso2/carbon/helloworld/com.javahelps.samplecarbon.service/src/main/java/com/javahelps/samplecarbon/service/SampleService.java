package com.javahelps.samplecarbon.service;

public class SampleService {
    private static final String[] LANGUAGES = { "Java", "C++", "Python", "Go" };

    public String[] getLanguages() {
        return LANGUAGES;
    }
}
