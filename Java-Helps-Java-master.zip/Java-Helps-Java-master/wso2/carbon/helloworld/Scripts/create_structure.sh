mkdir -p com.javahelps.samplecarbon.stub/src/main/java
mkdir -p com.javahelps.samplecarbon.stub/src/main/resources
mkdir -p com.javahelps.samplecarbon.stub/src/test/java
mkdir -p com.javahelps.samplecarbon.stub/src/test/resources
