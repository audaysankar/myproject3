/**
 * Sample Car class.
 *
 * @version 1.0
 * @author L.Gobinath
 */
public class Car {
    public void drive() {
        System.out.println("Use steering wheel");
    }
}