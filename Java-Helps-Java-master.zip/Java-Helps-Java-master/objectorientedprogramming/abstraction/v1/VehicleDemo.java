/**
 * Testing class for Vehicle class.
 * WARNING:
 *      This class gives compile time error.
 *      Cannot instantiate the abstract class.
 *
 * @version 1.0
 * @author L.Gobinath
 */
public class VehicleDemo {
    public static void main(String[] args) {
        Vehicle vehicle = new Vehicle();    // Compile time error
    }
}