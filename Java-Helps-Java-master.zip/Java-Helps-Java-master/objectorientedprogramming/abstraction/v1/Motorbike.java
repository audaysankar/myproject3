/**
 * Sample Motorbike class.
 *
 * @version 1.0
 * @author L.Gobinath
 */
public class Motorbike {
    public void drive() {
        System.out.println("Use handlebars");
    }
}