/**
 * CurrentAccount allows to have negative balance.
 *
 * @version 1.0
 * @author L.Gobinath
 */
public class CurrentAccount extends BankAccount {

}