/**
 * SavingsAccount does not have any significant differences.
 *
 * @version 1.0
 * @author L.Gobinath
 */
public class SavingsAccount extends BankAccount {

}