public interface Background {
    public void fill();
}