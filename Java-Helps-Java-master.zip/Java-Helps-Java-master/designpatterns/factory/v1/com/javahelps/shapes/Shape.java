package com.javahelps.shapes;

public interface Shape {
    public void draw();
}